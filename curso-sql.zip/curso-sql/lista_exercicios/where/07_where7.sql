SELECT IdProduto, DescNomeProduto
FROM produtos
WHERE DescNomeProduto LIKE '%chapéu%'

-- poderia ser usado o sinal de = já que a questão fala sobre "ser" chapeu