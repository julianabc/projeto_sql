
-- Todos os clientes que tenham clientes cadastrados

SELECT * 
FROM clientes
WHERE flEmail = 1