SELECT *
FROM produtos

-- sempre aspas simples para o sqlite, para conseguir pegar o valor

WHERE DescCategoriaProduto = 'rpg' 