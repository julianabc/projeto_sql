/* SQL Lite não possui truncate, aqui é utilizado o DELETE FROM */

DELETE FROM relatorio_diario;

SELECT * FROM relatorio_diario;

SELECT COUNT(*) FROM relatorio_diario;