SELECT IdProduto, DescNomeProduto
FROM produtos
WHERE DescNomeProduto LIKE 'Venda de%'