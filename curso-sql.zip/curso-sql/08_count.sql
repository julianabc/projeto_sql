SELECT count(*) as QtdeLinhas
FROM clientes