-- no workbench é show tables
.tables

