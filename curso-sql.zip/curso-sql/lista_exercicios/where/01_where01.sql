SELECT idCliente, QtdePontos
FROM transacoes
WHERE QtdePontos=1