SELECT idCliente, qtdePontos
FROM clientes
WHERE qtdePontos=0