SELECT *
FROM clientes
WHERE qtdePontos > 500