SELECT *
FROM produtos
LIMIT 10;