SELECT idCliente, qtdePontos, DtCriacao 
FROM clientes;


--- dá para fazer por blocos. só selecionar o que quer > clicar ao lado direito do mouse 
SELECT *
FROM clientes;
LIMIT 10;