SELECT *
FROM transacoes
WHERE QtdePontos = 50
